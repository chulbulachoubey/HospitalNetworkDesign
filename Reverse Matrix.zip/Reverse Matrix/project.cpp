#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
    char A[]={'a','b','c','d','e'};
    int i,j,k,l,m;
    static int count;
    cout<<"\n\nThe possible combinations of given letters taken one at a time:";
    for(i=0;i<5;i++)
        cout<<endl<<"("<<++count<<")"<<"\t"<<A[i];
    cout<<"\n\nThe possible combinations of given letters taken two at a time:";
    for(i=0;i<5;i++)
        for(j=0;j<5;j++)
            if(j!=i)
            cout<<endl<<"("<<++count<<")"<<"\t"<<A[i]<<A[j];
    cout<<"\n\nThe possible combinations of given letters taken three at a time:";
    for(i=0;i<5;i++)
        for(j=0;j<5;j++)
            if(j!=i)
            for(k=0;k<5;k++)
                if(k!=i&&k!=j)
                cout<<endl<<"("<<++count<<")"<<"\t"<<A[i]<<A[j]<<A[k];
    cout<<"\n\nThe possible combinations of given letters taken four at a time:";
    for(i=0;i<5;i++)
        for(j=0;j<5;j++)
            if(j!=i)
            for(k=0;k<5;k++)
                if(k!=i&&k!=j)
                for(l=0;l<5;l++)
                    if(l!=i&&l!=j&&l!=k)
                    cout<<endl<<"("<<++count<<")"<<"\t"<<A[i]<<A[j]<<A[k]<<A[l];
    cout<<"\n\nThe possible combinations of given letters taken five at a time:";
    for(i=0;i<5;i++)
        for(j=0;j<5;j++)
            if(j!=i)
            for(k=0;k<5;k++)
                if(k!=i&&k!=j)
                for(l=0;l<5;l++)
                    if(l!=i&&l!=j&&l!=k)
                    for(m=0;m<5;m++)
                        if(m!=i&&m!=j&&m!=k&&m!=l)
                        cout<<endl<<"("<<++count<<")"<<"\t"<<A[i]<<A[j]<<A[k]<<A[l]<<A[m];
}
