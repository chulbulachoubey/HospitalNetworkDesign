import time
import csv

def retMov(mood):
    "---------------I am collecting movies based on your Mood--------------"
    time.sleep(2)
    with open('F:\My Documents FIles\New My Documents\Projects\Project 6th Sem\Data\bollywoodcopy.csv', mode='r') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        line_count = 0
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
        print(f'\t{row["name"]} works in the {row["department"]} department, and was born in {row["birthday month"]}.')
        line_count += 1
    print(f'Processed {line_count} lines.')
    return


print("Welcome to Movie Recommendation System\n")
print("We will be Suggesting you movies based on your mood right now!!!")
start=str(input("Shall we begin??(Y/N)\n"))
if start=="Y" or start=="y":
    mood=int(input("How are you feeling today?\n1.Happy\n2.Sad\n3.Aroused\n4.Unpleasant\n5.Relaxed\n6.Sleepy\n7.Excited\n8.Bored\n9.Pleasant\n10.Stressed\n11.Neutral\n"))
    retMov(mood)
else:
    print("You are exiting the program...................\nBye\nVisit Soon")
    time.sleep(5)
    exit()



